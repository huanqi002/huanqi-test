<?php
require __DIR__ . '/../general/config.php';
require __DIR__ . '/../general/auth.php';
require __DIR__ . '/../general/notifications.php';
require __DIR__ . '/functions.php';
require __DIR__ . '/calendar_functions.php';
require __DIR__ . '/../history_management/functions.php';

requireLogin();

$sessionId = (int)($_POST['session_id'] ?? 0);
$reason    = trim((string)($_POST['reason'] ?? ''));
$me        = currentUser();

if ($reason === '') {
    header('Location: index.php?err=' . urlencode('Please give a reason for cancelling the session.'));
    exit;
}
$reason = mb_substr($reason, 0, 500);

$session = findActiveSession($conn, $sessionId);

if (!$session || !isMySession($session, (int)$me['id'], $me['role'])) {
    header('Location: index.php?err=' . urlencode('This session cannot be cancelled.'));
    exit;
}

$conn->begin_transaction();
try {
    updateSessionStatus($conn, $sessionId, 'Cancelled');
    recordHistory($conn, $session, 'Cancelled', $reason);

    $category = $session['category'];
    $participants = [
        (int)$session['user_id']      => $session['volunteer_name'],
        (int)$session['volunteer_id'] => $session['student_name'],
    ];
    foreach ($participants as $userId => $otherName) {
        $message = $userId == $me['id']
            ? "You cancelled your $category session with $otherName."
            : "{$me['name']} cancelled your $category session. Reason: $reason";
        addNotification($conn, $userId, mb_strimwidth($message, 0, 500, "..."), 'Session Cancelled', $sessionId);
    }

    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    header('Location: index.php?err=' . urlencode('Something went wrong. Please try again.'));
    exit;
}

syncCalendarOnCancel($session);
header('Location: index.php?done=cancelled');
exit;
