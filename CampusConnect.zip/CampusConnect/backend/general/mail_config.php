<?php
// Local Gmail SMTP credentials. Keep this file private and out of version control.
return [
    'provider' => 'gmail',
    'sender_email' => 'melvinczl666@gmail.com',
    'app_password' => 'qwsz ggwt pqib nguc',
];