<?php
return [
    'client_id'     => '487148148390-pmlu4uovucnqb2l5tsokdbdp6kkb2i4b.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri'  => 'http://localhost/CampusConnect/backend/session_management/oauth_callback.php',
];
